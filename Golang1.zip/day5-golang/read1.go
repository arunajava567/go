package main

import (
	"fmt"
	"io/ioutil"
)

func main() {
	fs, err := ioutil.ReadFile("test.txt")
	if err != nil {
		fmt.Println("Error is: ", err)
	}

	str := string(fs)
	fmt.Println(str)
}