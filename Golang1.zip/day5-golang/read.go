package main
import (
	"fmt"
	"os"
)
func main() {
	file, err := os.Open("test.txt")
	if err != nil {
		fmt.Println("erros is: ", err)
		return
	}
	defer file.Close()
	size, err := file.Stat()
	if err != nil {
		fmt.Println("erros is: ", err)
		return
	}
	fs := make([]byte, size.Size())
	_, err = file.Read(fs)
	if err != nil {
		fmt.Println("erros is: ", err)
		return
	}
	str := string(fs)
	fmt.Println(str)
}