package main
��
import (
���������"fmt"
���������"time"
)
��
func main() {
	now := time.Now()
	fmt.Println(now)
��date1 := time.Date(2015, time.May, 21, 23, 10, 52, 211, time.UTC)
  date1:=time.Date(2009,00,00,00,00,00,00,time.UTC)

fmt.Println(date1)
fmt.Println(date2) 

diff := now.Sub(pastDate)
��
hrs := int(diff.Hours())
fmt.Printf("Diffrence in Hours : %d Hours\n", hrs)
��
mins := int(diff.Minutes())
fmt.Printf("Diffrence in Minutes : %d Minutes\n", mins)
��
second := int(diff.Seconds())
fmt.Printf("Diffrence in Seconds : %d Seconds\n", second)
��
days := int(diff.Hours() / 24)
fmt.Printf("Diffrence in days : %d days\n", days)
��
��
futureDate := time.Date(2018, time.June, 1, 23, 10, 52, 211, time.UTC)
fmt.Println("Future� : ", loc, " Time : ", futureDate) // 

diff = futureDate.Sub(now)
��
hrs = int(diff.Hours())
fmt.Printf("Diffrence in Hours : %d Hours\n", hrs)
��
mins = int(diff.Minutes())
fmt.Printf("Diffrence in Minutes : %d Minutes\n", mins)
��
second = int(diff.Seconds())
fmt.Printf("Diffrence in Seconds : %d Seconds\n", second)
��
days = int(diff.Hours() / 24)
fmt.Printf("Diffrence in days : %d days\n", days)
��
}