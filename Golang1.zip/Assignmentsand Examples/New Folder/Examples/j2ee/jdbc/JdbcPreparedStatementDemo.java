//Jdbc PreparedStatement Demo 
//To insert records into books table
import java.sql.*;
public class JdbcPreparedStatementDemo
{
    public static void main(String[] args)
   {
   try
  {
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
PreparedStatement st = con.prepareStatement(�insert into books values(?,?,?)�);
st.setInt(1,444);
st.setString(2,�XML�);
st.setInt(3,500);
st.executeUpdate();
System.out.println(�One Record Inserted�);
  }
  catch(Exception e)
 {
System.out.println(e);
}
}
}
