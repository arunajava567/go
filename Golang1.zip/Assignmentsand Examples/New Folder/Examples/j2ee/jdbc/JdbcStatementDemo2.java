//Jdbc Statement Demo 2 - to insert records into books table
import java.sql.*;
public class JdbcStatementDemo2
{
    public static void main(String[] args)
   {
   try
  {
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
Statement st = con.createStatement();
st.executeUpdate(�insert into books values(111,�Java�,500);
System.out.println("One row inserted");
  }
  catch(Exception e)
 {
System.out.println(e);
}
}
}
