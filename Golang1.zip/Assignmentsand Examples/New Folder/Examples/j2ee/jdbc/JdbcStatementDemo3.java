//Jdbc StatementDemo 3 - to retrive records from a table 
//using executeQuery()
import java.sql.*;
public class JdbcStatementDemo3
{
    public static void main(String[] args)
   {
   try
  {
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
Statement st = con.createStatement();
ResultSet rs = st.executeQuery(�select * from books�);
while(rs.next())
{
	System.out.print(rs.getInt(�bno�)+� �);
	System.out.print(rs.getString(�bname�)+ � �);
	System.out.println(rs.getInt(�price�));
}
  }
  catch(Exception e)
 {
System.out.println(e);
}
}
}
