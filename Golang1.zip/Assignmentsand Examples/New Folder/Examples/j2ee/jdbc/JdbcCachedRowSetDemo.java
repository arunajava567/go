/*
  * This is a basic sample that illustrates the use of CachedRowSet.
  * This presents the basic use case and shows how operations happen in the
  * memory and are then synchronized back to the database.
  */

 //Import the necessary packages.

 import java.sql.*;

 import javax.sql.*;
 import com.sun.rowset.CachedRowSetImpl;




 import javax.sql.rowset.*;
import com.sun.rowset.*;


 public class JdbcCachedRowSetDemo {
        public static void main(String args[]){

 	     Connection con ;

         try{

 	         Class.forName("oracle.jdbc.driver.OracleDriver");

		 con = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vani", "infy");

 		Statement stmt = c.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);


 		 // Declaring the object to be instantiated through
		 // the CachedRowSet interface.

		 CachedRowSet crset = new CachedRowSetImpl();

		 ResultSet rs = stmt.executeQuery("SELECT eno,ename,age FROM emp");

              crset.populate(rs);

	  	  con.close();  // close the connection after populating the data


 		 while (crset.next()) {
		       System.out.println(crset.getInt("ENO"));
		    }

              crset.beforeFirst();
 		        while(crset.next()) {
 		            if(crset.getInt("ENO") == 1001) {
 		                 System.out.println("Age: "+crset.getInt("age"));
 		                 crset.updateInt("age",30);
 		                 crset.updateRow();

 		  // Get the connection and set the table name to which updation has to be made

                con = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vanikn", "infy");
                crset.setTableName("emp");

 		              }
 		           }
 		  // Syncing the row back to the DB
 		     crset.acceptChanges(con);


 		      //  Inserting a new row


 			crset.moveToInsertRow();
 			crset.updateInt("Eno",1005);
 			crset.updateString("ENAME","Sita");
 			crset.updateInt("age",24);
 			crset.insertRow();
 			crset.moveToCurrentRow();

 			// Syncing the new row back to the database.

 			crset.acceptChanges(con);
                crset.close();
            	con.close();

     	  }catch(Exception e){
       		 System.out.println(" Hello there is an exception :Exception" + e);

     }
  }
}