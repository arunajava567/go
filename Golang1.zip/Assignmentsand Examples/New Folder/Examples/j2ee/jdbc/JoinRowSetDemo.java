 //Import the necessary packages.

 import java.sql.*;
 import javax.sql.*;
 import javax.sql.rowset.*;

 import com.sun.rowset.CachedRowSetImpl;
 import com.sun.rowset.JoinRowSetImpl;
 import com.sun.rowset.*;

 public class JoinRowSetDemo {
   public static void main(String args[]){


 	  Connection c ;
 	  //String dbCommand = "select eno,ename,age FROM emp";

      try{

 	   Class.forName("oracle.jdbc.driver.OracleDriver");
     	 	//  Class.forName("com.inet.ora.OraDriver");

 			// c = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.41:1521:ora3", "knvani", "knvani");


 			 c = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vanikn", "infy");

 		//	Statement stmt = c.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

 			 Statement stmt8 = c.createStatement();
 	          ResultSet rs = stmt8.executeQuery("select a.eno, a.ename, a.age, a.deptid from EMP a");

 	          Statement stmt9 = c.createStatement();
 	          ResultSet rs1 = stmt9.executeQuery("select d.deptid, d.dname from DEPT d");

 	          // Now populate two cached RowSets and add them to a JoinRowSet.

 	         JoinRowSet jrs = new JoinRowSetImpl();
 	          CachedRowSet crs1 = new CachedRowSetImpl();
 	         // crs1.setMatchColumn("deptid");
 	          crs1.populate(rs);
 	          System.out.println("Size of the first cached rowset is: "+crs1.size());
 	         jrs.addRowSet(crs1,"deptid");

 	          CachedRowSet crs2 = new CachedRowSetImpl();
 	         // crs2.setMatchColumn("deptid");
 	          crs2.populate(rs1);
 	          System.out.println("Size of the second cached rowset is: "+crs2.size());

 	         // JoinRowSet jrs = new JoinRowSetImpl();
 	         // jrs.addRowSet(crs1);
 	          jrs.addRowSet(crs2,"deptid");

 	          System.out.println("Size of the joinRowSet is: "+jrs.size());
 	          System.out.println("Contents are");

 	         jrs.beforeFirst();
 	          while(jrs.next()) {
 	            System.out.println("---------------------------------");
 	     		System.out.println("Emp No : "+jrs.getObject(1));
 	     		System.out.println("Name: "+jrs.getObject(2));
 	     		System.out.println("Age: "+jrs.getObject(3));
 	     		System.out.println("Department Name: "+jrs.getObject(5));

 	     		System.out.println("---------------------------------");
 	          }

                jrs.close();
				c.close();

     	  }catch(Exception e){
       		 System.out.println(" Hello there is an exception :Exception" + e);

     }
  }
}