//JdbcType1 Driver Demo
import java.sql.*;
public class JdbcType1Driver
{
    public static void main(String[] args)
   {
   try
  {
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con = DriverManager.getConnection("jdbc:odbc:nexwave", "scott", "tiger");
//nexwave is the DSN which is created in ODBC (Microsoft ODBC for Oracle) in Control Panel->Administrative Tools
System.out.println("Connected");
  }
  catch(Exception e)
 {
System.out.println(e);
}
}
}
