/**

  * This is a basic program to demonstrate the use of a JdbcRowSet.
  */


 // Import the necessary packages

import java.sql.*;
import java.sql.ResultSet;


import javax.sql.rowset.*;
import com.sun.rowset.*;


public class JdbcRowSetDemo {
  public static void main(String args[]){
	  JdbcRowSet jdbcRs;

	  ResultSet rs ;

	  Connection con ;
     try{

	          Class.forName("oracle.jdbc.driver.OracleDriver");


		   con = DriverManager.getConnection ("jdbc:oracle:thin:@10.122.130.31:1521:training", "vani", "infy");

		   Statement stmt = c.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);


		   rs = stmt.executeQuery("SELECT eno,ename,age FROM emp");


                 // Creating a new JdbcRowSet
		   jdbcRs = new JdbcRowSetImpl(rs);

        	    jdbcRs.next();
	            System.out.println(jdbcRs.getString(2));

                // Moving the cursor to the first row and updating

		jdbcRs.absolute(1);
		jdbcRs.updateInt("age", 30);
		jdbcRs.updateRow();
		jdbcRs.next();

		// Inserting a Row
		jdbcRs.first();
		jdbcRs.moveToInsertRow();
		jdbcRs.updateInt("ENO", 1004);
		jdbcRs.updateString("ENAME", "pqr");
		jdbcRs.updateInt("age", 45);
		jdbcRs.insertRow();

		jdbcRs.moveToCurrentRow();
		jdbcRs.next();

		System.out.println(jdbcRs.getInt(1));

		jdbcRs.close();
		c.close();

     	  }catch(Exception e){
       		 System.out.println(" Hello there is an exception :Exception" + e);

     }
  }
}
