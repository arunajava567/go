import java.net.*;

public class UDPReceiver {

  public static void main(String args[]) {
  
    byte[] buffer = new byte[8096];
    DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
  
  }

}
