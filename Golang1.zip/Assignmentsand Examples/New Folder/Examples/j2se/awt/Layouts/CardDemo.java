import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*<applet code=CardDemo width=400 height=200></applet>*/

public class CardDemo extends Applet implements ActionListener, MouseListener
{
		Checkbox Win98, WinNT, solaris, mac;

		Panel osCards;
		
		CardLayout cardLO;
		
		Button Win, Other;

		public void init()
		{
				Win = new Button("Windows");
				Other = new Button("Other");
		
				add(Win);
				add(Other);
			
				cardLO = new CardLayout();

				osCards = new Panel();
				
				osCards.setLayout(cardLO);		// set panel layout to card layout

				Win98 = new Checkbox("Windows 98" , null, true);
				WinNT = new Checkbox("Windows NT");
				solaris = new Checkbox("Solaris");
				mac = new Checkbox("MacOS");

				// add Windows check boxes to a panel

				Panel winPan = new Panel();

				winPan.add(Win98);
				winPan.add(WinNT);

				// Add other OS check boxes to a panel

				Panel otherPan = new Panel();

				otherPan.add(solaris);
				otherPan.add(mac);

				// add panels to card deck panel
				osCards.add(winPan, "Windows");
				osCards.add(otherPan, "Other");

				// add cards to main applet panel
				add(osCards);

				// register to receive action events
				Win.addActionListener(this);
				Other.addActionListener(this);

				// register mouse events
				addMouseListener(this);
		}

		// Cycle through panels
		public void mousePressed(MouseEvent e)
		{
				cardLO.next(osCards);
		}

		public void mouseClicked(MouseEvent e){};
		
		public void mouseReleased(MouseEvent e)	{};

		public void mouseEntered(MouseEvent e){};

		public void mouseExited(MouseEvent e){};

		public void actionPerformed(ActionEvent ae)
		{
				if(ae.getSource() == Win)
				{	
						cardLO.show(osCards, "Windows");
				}
				else
				{	
						cardLO.show(osCards, "Other");
				}
		}
}