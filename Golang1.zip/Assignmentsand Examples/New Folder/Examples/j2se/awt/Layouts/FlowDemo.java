import java.awt.*;

public class FlowDemo extends Frame
{
    Label ln = new Label("Name");

    TextField tf = new TextField(20);

    public FlowDemo(String s)
    {
		super(s);
		setLayout(new FlowLayout());
		add(ln);
		add(tf);
    }

    public static void main(String args[])
    {
		FlowDemo fd = new FlowDemo("FlowLayout  Demo");
		fd.setSize(500, 500);
		fd.setVisible(true);
    }		
}