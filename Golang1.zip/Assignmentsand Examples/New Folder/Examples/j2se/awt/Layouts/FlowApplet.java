import java.awt.*;
import java.applet.*;

/*
<applet code=FlowApplet width=500 height=500>
</applet>
*/

public class FlowApplet extends Applet
{
	public void init()
	{
		TextField tf = new TextField(20);

		Label ln = new Label("Name : ");
		
		Button bt = new Button("Ok");

		add(ln);
		add(tf);
		add(bt);
	}
}