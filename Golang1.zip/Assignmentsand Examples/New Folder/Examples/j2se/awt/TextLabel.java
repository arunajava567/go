import java.awt.*;

public class TextLabel extends Frame
{
		TextField txtName = new TextField(20);

		Label lblName = new Label("Name : ");

		public TextLabel(String s)
		{
				super(s);
				setLayout(new FlowLayout());
				add(lblName);
				add(txtName);
		}

		public static void main(String[] args) 
		{
			TextLabel fd = new TextLabel("Testing Components");
			fd.setSize(300, 300);
			fd.show();
		}
}