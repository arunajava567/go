import java.awt.*;

public class PanelDemo extends Panel
{
		public static void main(String[] args) 
		{
			PanelDemo pd = new PanelDemo();
	
			TextField tf = new TextField(10);
			pd.add(tf);

			Frame f = new Frame("Panel Demo");
			
			f.add(pd);
			f.setSize(300, 300);
			f.setVisible(true);
		}
}