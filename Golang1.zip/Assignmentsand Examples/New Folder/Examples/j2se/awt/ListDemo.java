import java.awt.*;

public class ListDemo extends Frame
{
		Label lbl = new Label("Who is your favorite movie star?");

		Choice ch = new Choice();

		public ListDemo(String s)
		{
				super(s);
				setLayout(new FlowLayout());
				ch.addItem("Amithab Bhachan");
				ch.addItem("Bobby Deol");
				ch.addItem("Sharukh Khan");
				ch.addItem("Hrithik Roshan");
				ch.addItem("Leonardo DiCaprio");

				add(lbl);
				add(ch);
		}

		public static void main(String[] args) 
		{
			ListDemo fd = new ListDemo("A sky full of stars...");
			fd.setSize(400, 400);
			fd.show();
		}
}