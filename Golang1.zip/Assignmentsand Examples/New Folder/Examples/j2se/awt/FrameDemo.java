import java.awt.*;

public class FrameDemo extends Frame
{
		Label l = new Label("Welcome to AWT");

		public FrameDemo(String s)
		{
				super(s);
				add(l);
		}

		public static void main(String[] args) 
		{
			FrameDemo fd = new FrameDemo("AWT Classes");
			fd.setSize(300, 300);
			fd.setVisible(true);
		}
}