import java.awt.event.*;
import java.applet.*;

/*
<applet code=AnonymousClassDemo width=300 height=300>
</applet>
*/

public class AnonymousClassDemo extends Applet
{
		public void init()
		{
			addMouseListener(new MouseAdapter()
									{
										public void mousePressed(MouseEvent me)
										{
											showStatus("Mouse Pressed.");
										}
									});
		}
}