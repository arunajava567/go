import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code=MouseEventsDemo width=250 height=200>
</applet>
*/

public class MouseEventsDemo extends Applet implements MouseListener, MouseMotionListener
{
		String msg = "";

		// Coordinates of mouse
		int mx = 0, my = 0;

		public void init()
		{
				addMouseListener(this);
				addMouseMotionListener(this);
		}

		// Overriding Methods belong to Mouse Listener. 5 Methods Overridden
		public void mouseClicked(MouseEvent me)
		{
				//save coordinates
				mx = 0;
				my = 0;
				msg = "Mouse Clicked";
				repaint();
		}

		public void mouseEntered(MouseEvent me)
		{
				//save coordinates
				mx = 0;
				my = 10;
				msg = "Mouse Entered";
				repaint();
		}

		public void mouseExited(MouseEvent me)
		{
				//save coordinates
				mx = 0;
				my = 10;
				msg = "Mouse Exited";
				repaint();
		}

		public void mousePressed(MouseEvent me)
		{
				//save coordinates
				mx = me.getX();
				my = me.getY();
				msg = "Down - Mouse Pressed";
				repaint();
		}

		public void mouseReleased(MouseEvent me)
		{
				//save coordinates
				mx = me.getX();
				my = me.getY();
				msg = "Up - Mouse Released";
				repaint();
		}

		// Overriding Methods belong to Mouse Motion Listener. 2 Methods Overridden	
		public void mouseDragged(MouseEvent me)
		{
				//save coordinates
				mx = me.getX();
				my = me.getY();
				msg = "*";
				showStatus("Dragging mouse at " + mx + ", " + my);
				repaint();

		}
		public void mouseMoved(MouseEvent me)
		{
				showStatus("Moving mouse at " + me.getX() + ", " + me.getY());
		}

		public void paint(Graphics g)
		{
				g.drawString(msg, mx, my);
		}
}