package pack1;

public class Product
{
	public int mul(int num1,int num2)
	{
		return num1 * num2;
	}
}