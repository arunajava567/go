class concat{
	public static void main(String[] args){
		String str1 = "Table";
		String str2 = "Tennis";
		String Game = str1 + " " + str2;
		System.out.println(Game);
		}
}