public class StrSearch{
	public static void main(String args[]){
	String s = "Bonjour";
	//String begin = 1;
	String t = s.substring(1);   
	System.out.println(t);
	}
}	