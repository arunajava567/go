class Test16
{
	public static void main(String args[])
	{
		String[] s = new String[5];
		System.out.println(s[10]);
	}
}