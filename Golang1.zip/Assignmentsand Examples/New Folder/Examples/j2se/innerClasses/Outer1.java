class Outer1
{
	class Inner1
	{
		public static void main(String args[])
		{
			System.out.println("outer class main method-----");
		}
	}
}