class Outer7
{
	static class Inner7{}
}