	package main  
	import "fmt"  
	func main() {  
	   /* local variable definition */  
	   var a int = 10  
	   /* check the boolean condition using if statement */  
	   if( a % 2==0 ) {      /* if condition is true then print the following 
	*/ fmt.Printf("a is even number" )  
	   }  
	}  
