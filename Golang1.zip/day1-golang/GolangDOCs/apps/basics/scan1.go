package main  
import "fmt"  
func main() {  
   var input int  
fmt.Printf("enter a number")
    fmt.Scanln(&input)
    
   fmt.Println(input)
}  