package main
import  (
	//"fmt"
	"time"
)
type Product struct{
 id int
 name string
 pricelist []int
 mdate time.Time
} //time.Date(2018,05,10,03,40,00,00,time.UTC)
var p []Product

func main() {
	//Product{id:101,name:"Bag",pricelist:[] int{45,67,89},mdate:time.Date(2018,05,10,03,40,00,00,time.UTC) }
/*pp:=&p

fmt.Println(pp)
fmt.Println(**pp)
fmt.Println(p.id,p.name,p.pricelist[0],p.pricelist[1],p.pricelist[2],p.mdate)
temp:=p.mdate.AddDate(2, 6, 0)
fmt.Println(temp)
fmt.Println(p.mdate)
//fmt.Println(p[0].id,p[0].name,p[0].pricelist[0],p.pricelist[1],p.pricelist[2],p[0].mdate.AddDate(0,8,0))

fmt.Println(p.id,p.name,p.pricelist[0],p.pricelist[1],p.pricelist[2],p.mdate.AddDate(0,6,0))
fmt.Println(p.mdate)
*/

}

