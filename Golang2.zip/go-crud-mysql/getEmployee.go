package main

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
)

type Employee struct {
    Id    int
    Name  string
    City string
}

var db *sql.DB
var err error

func getEmployee(id int)  {
	fmt.Println("===entered===")
	db, err = sql.Open("mysql", "root:root@127.0.0.1:3306/goblog")
	//defer db.Close()
	if err != nil {
		fmt.Println(err.Error())
	}

	err = db.Ping()
	fmt.Println("connected..")
	if err != nil {
		fmt.Println(err.Error())
	}
	var e Employee
	db = db.QueryRow("select id,name,city from employee WHERE id = 1").Scan(&e.Id, &e.Name, &e.City)

	//if err != nil {
	//	fmt.Println("222"+err.Error())
	//}
  //err=db.Scan(&e.Id, &e.Name, &e.City)
 //e.Id=id
 //e.Name=name
 //e.City=city
  fmt.Printf("Employee ID: %d\n Name: %s\n City: %s\n", e.Id,e.Name,e.City)

	
}

func main() {

	getEmployee(1)

}