package main
import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/go-sql-driver/mysql"
)

func main() {
	db, err0 := sql.Open("mysql", "root:root@tcp(127.0.0.1:3306)/cts")
	if err0 != nil {
			log.Fatal(err0)
	}
  fmt.Printf("connected...")
	

	row, err := db.Query("select id,name,age from user")
	if err != nil {
			panic(err)
	}
	for row.Next() {
			var id, age int
			var name string
			row.Scan(&id, &name, &age)
			fmt.Println(id, "\t", name, "\t", age)
	}
	fmt.Println("done..")
	defer db.Close()
}