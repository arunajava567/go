package main
import (
	 "fmt"
    "time"
)
type product struct { 
     Description string
     Weight float32
     Price  float32
     mdate time.Time
     ubmon int
     edate time.Time
}
var productMap = make(map[int]*product)
var t1,t2 int


func calExpDate(){
	fmt.Println(productMap)
     for _,v := range productMap {
  temp1:= v.mdate.AddDate(0, v.ubmon, 0)
  v.edate=temp1
  fmt.Println(temp1)
  fmt.Println("===in cslExpDate===",v.mdate,"++++",v.edate)
  }
 }
 func displayNewDetails() {
	fmt.Println(productMap)
    for _,v := range productMap {
//		temp1:= v.mdate.AddDate(0, v.ubmon, 0)
//		v.edate=temp1
//		fmt.Println(temp1)
		fmt.Println("===in dispExpDate===",v.mdate,"++++",v.edate)
		}
		   
 }

 
func main() {
     productMap[0]=product{"a",4.00,5.00,time.Date(2018,05,10,03,40,00,00,time.UTC),7,time.Date(0000,00,00,00,00,00,00,time.UTC)}
	fmt.Println(productMap)
    
	calExpDate()
	displayNewDetails()
	for _,v := range productMap {
		//temp1:= v.mdate.AddDate(0, v.ubmon, 0)
		//v.edate=temp1
		//fmt.Println(temp1)
		fmt.Println("===in  main===",v.mdate,"++++",v.edate)
		}
	
    }
