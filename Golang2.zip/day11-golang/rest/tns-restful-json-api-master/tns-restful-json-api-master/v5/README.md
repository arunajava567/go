# Example 5

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v5/*.go
```
