# Example 9

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v9/*.go
```
