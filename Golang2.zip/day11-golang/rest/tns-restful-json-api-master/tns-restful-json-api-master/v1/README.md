# Example 1

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v1/*.go
```
