# Example 3

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v3/*.go
```
