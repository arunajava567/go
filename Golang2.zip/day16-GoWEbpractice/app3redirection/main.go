package main
import (
        "fmt"
        "net/http"
       helper "./helpers"
   )

func main() {
   uName,email,pwd,pwdConfirm :="","","",""
   mux:=http.NewServeMux()
   mux.HandleFunc("/signup",func(w http.ResponseWriter, r *http.Request) {
   r.ParseForm()
   email=r.FormValue("email")
   pwd=r.FormValue("password")
   emailCheck:=helper.IsEmpty(email)
   pwdCheck:=helper.IsEmpty(pwd)
   if emailCheck || pwdCheck {
      fmt.Fprintf(w,"Error : There is empty data")
       return
   }
   dbPwd:="cts123"
   dbEmail:="cts@cognizant.com"  
   if email==dbEmail && pwd==dbPwd {
      fmt.Println(w,"Login Success",uName,pwdConfirm)
   } else {
      fmt.Println(w,"Login Failed")
   }
})
   http.ListenAndServe(":8090",mux)
}
  
























